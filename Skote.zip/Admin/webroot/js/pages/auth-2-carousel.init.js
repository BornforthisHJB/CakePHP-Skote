/*
Template Name: Skote - Admin & Dashboard Template
Author: Themesbrand
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: auth 2 carousel Init Js File
*/

$('#auth-review-carousel').owlCarousel({
    items: 1,
    loop: false,
    margin: 16,
    nav: false,
    dots: true,
});